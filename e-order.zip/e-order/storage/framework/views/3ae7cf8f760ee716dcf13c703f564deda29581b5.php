
<?php $__env->startSection('judul','List Menu Pelanggan'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-body">
  <!-- row -->
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-1 col-sm-12">
      </div>
      <div class="col-lg-10 col-sm-12">
        <div class="card garis">
          <div class="stat-widget card-body">
            <div class="stat-content itam">
              <div id="cetak">
                <center>
                  <h1>Bill Meja Pelanggan</h1>
                </center>
                <hr style="border:2px solid black;">
                <table>
                  <tr>
                    <td>Nomor Meja</td>
                    <td style="width:20px;">
                      <center>:</center>
                    </td>
                    <td><?php echo e($orderan->nomor_meja); ?></td>
                  </tr>
                  <tr>
                    <td>Kode Pembayaran</td>
                    <td style="width:20px;">
                      <center>:</center>
                    </td>
                    <td><?php echo e($orderan->kode_pembayaran); ?></td>
                  </tr>
                  <tr>
                    <td align="left">Nama Pelanggan</td>
                    <td style="width:20px;">
                      <center>:</center>
                    </td>
                    <td><?php echo e($orderan->pelanggan); ?></td>
                  </tr>
                </table>
                <br>
                <table width="100%">
                  <tr style="margin-bottom:10px;border-bottom:1px solid black;">
                    <td>Menu</td>
                    <td>Jumlah & Harga</td>
                    <td>Total</td>
                  </tr>
                  <?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                  $jumlah_pesanan = \App\Models\Orderan::where('id_menu',$o->id_menu)->where('kode_pembayaran',$o->kode_pembayaran)->where('status_menu','1')->sum('jumlah');
                  $total = $jumlah_pesanan * $o->menu->harga;
                  $sub_total[] = $total;
                  ?>
                  <tr>
                    <td><?php echo e($o->menu->nama_menu); ?></td>
                    <td><?php echo e($jumlah_pesanan); ?> X <?php echo e(number_format($o->menu->harga)); ?></td>
                    <td><?php echo e(number_format($total)); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td colspan="2"></td>
                    <td>_______+</td>
                  </tr>
                  <tr>
                    <td colspan="2">Total</td>
                    <td><?php echo e(number_format(@array_sum($sub_total))); ?></td>
                  </tr>
                </table>
              </div>
              <hr style="border:2px solid black;">
              <div class="row">
                <?php
                $totalan = array_sum($sub_total);
                ?>
                <div class="col-md-12">
                  <a href="<?php echo e(route('dashboard_kasir')); ?>" class="btn btn-danger">Kembali</a>
                  <button onclick="printCertificate()" class="btn btn-info"> Cetak Bill Menu</button>
                  <a href="<?php echo e(route('proses_pembayaran',[$totalan,$orderan->kode_pembayaran])); ?>" class="btn btn-success">Pembayaran</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-1 col-sm-12">
      </div>
    </div>
  </div>
</div>
<?php $__env->startSection('tambahan'); ?>
<script>
  function printCertificate() {
    const printContents = document.getElementById('cetak').innerHTML;
    const originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
  }
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.kasir_dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e-order\resources\views/kasir/pesanan.blade.php ENDPATH**/ ?>
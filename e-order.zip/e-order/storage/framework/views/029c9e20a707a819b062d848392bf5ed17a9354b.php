<html>

<head>
  <title>Laporan Transaksi MGG</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>

  <div class="container">
    <center>
      <h2>Laporan Transaksi MGG</h2>
      <h5>Periode : <?php echo e(date('d-m-Y',strtotime($mulai))); ?> .Sd. <?php echo e(date('d-m-Y',strtotime($selesai))); ?></h5>
    </center>
    <br />
    <table class='table table-bordered'>
      <thead>
        <tr>
          <th>No</th>
          <th>
            <center>Nomor Meja</center>
          </th>
          <th>
            <center>Kode Pembayaran</center>
          </th>
          <th>
            <center>Nama Pelanggan</center>
          </th>
          <th>
            <center>Harga</center>
          </th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $sub_total[] = $t->total_harga;
        ?>
        <tr>
          <td><?php echo e(++$n); ?></td>
          <td><?php echo e($t->kode_meja); ?></td>
          <td><?php echo e($t->kode_pembayaran); ?></td>
          <td><?php echo e($t->pelanggan); ?></td>
          <td>
            <center>Rp. <?php echo e(number_format($t->total_harga)); ?></center>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td colspan="4">
            <center>Total</center>
          </td>
          <td>
            <center>Rp. <?php echo e(number_format(@array_sum($sub_total))); ?></center>
          </td>
        </tr>
      </tbody>
    </table>

  </div>

</body>
<script>
  window.print();
</script>

</html><?php /**PATH C:\laragon\www\e-order\resources\views/cetak/laporan_transaksi.blade.php ENDPATH**/ ?>
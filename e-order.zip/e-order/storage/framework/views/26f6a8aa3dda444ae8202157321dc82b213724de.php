
<?php $__env->startSection('judul','Edit Data Meja'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-body">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <center>
              <h1>Form Edit Meja</h1>
            </center>
            <hr>
            <form action="<?php echo e(route('proses_edit_meja',$data->id_meja)); ?>" method="POST" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

              <div class="form-group row">
                <div class="col-md-2"></div>
                <div class="col-md-8">
                  <label for="nomor_meja" class="itam">Nomor Meja</label>
                  <input type="text" value="<?php echo e($data->nomor_meja); ?>" name="nomor_meja" class="form-control" id="nomor_meja" placeholder="Nomor Meja">
                </div>
                <div class="col-md-2"></div>
              </div>
              <hr>
              <div class="form-group row">
                <div class="col-md-2"></div>
                <div class="col-md-8" align="right">
                  <button type="submit" class="btn btn-success"><i class="fa fa-paper-plane-o"></i> Simpan</button>
                  <a href="<?php echo e(route('meja')); ?>" class="btn btn-danger"><i class="fa fa-close"></i> Batal</a>
                </div>
                <div class="col-md-2"></div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master_dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e-order\resources\views/dashboard/meja/form_edit.blade.php ENDPATH**/ ?>
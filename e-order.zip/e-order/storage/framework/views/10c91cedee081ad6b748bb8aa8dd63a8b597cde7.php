
<?php $__env->startSection('judul','Halaman Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-sm-6">
                <div class="card">
                    <div class="stat-widget-two card-body">
                        <div class="stat-content">
                            <div class="stat-text">Menu Makanan </div>
                            <div class="stat-digit"> <?php echo e($jumlah_makanan); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="card">
                    <div class="stat-widget-two card-body">
                        <div class="stat-content">
                            <div class="stat-text">Jumlah Minuman</div>
                            <div class="stat-digit"> <?php echo e($jumlah_minuman); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="card">
                    <div class="stat-widget-two card-body">
                        <div class="stat-content">
                            <div class="stat-text">Jumlah Meja Pelanggan</div>
                            <div class="stat-digit"> <?php echo e($jumlah_meja); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="card">
                    <div class="stat-widget-two card-body">
                        <div class="stat-content">
                            <div class="stat-text">Jumlah Orderan</div>
                            <div class="stat-digit"> <?php echo e($jumlah_pesanan); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Dashboard</h4>
                    </div>
                    <div class="card-body">
                        <center>
                            <img src="<?php echo e(asset('mgg/mgg/mgg_menu2.png')); ?>" width="70%">
                        </center>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master_dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e-order\resources\views/dashboard/index.blade.php ENDPATH**/ ?>
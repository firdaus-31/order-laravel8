
<?php $__env->startSection('judul','Menu Makanan'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-body">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Tabel Data Makanan</h4>
                    </div>
                    <div class="card-body">
                        <a href="<?php echo e(route('add_menu',1)); ?>" class="btn btn-success"><i class="fa fa-plus"></i> Tambah Data Makanan</a>
                        <hr>
                        <div class="table-responsive">
                            <table id="example" class="display" style="min-width: 845px">
                                <thead>
                                    <tr>
                                        <th>Nomer</th>
                                        <th>Nama Makanan</th>
                                        <th>Harga</th>
                                        <th>Dapur</th>
                                        <th>Gambar</th>
                                        <th>Proses</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $makanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="itam"><?php echo e(++$n); ?></td>
                                        <td class="itam"><?php echo e($m->nama_menu); ?></td>
                                        <td class="itam">Rp. <?php echo e(number_format($m->harga)); ?></td>
                                        <?php $__currentLoopData = $dapur->where('id_dapur',$m->id_dapur); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td class="itam"><?php echo e($dp->nama_dapur); ?></td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td><img src="<?php echo e(asset('foto_makanan/'.$m->foto_menu)); ?>" width="100px" height="100px"></td>
                                        <td>
                                            <center>
                                                <a href="<?php echo e(route('edit_makanan',$m->id_menu)); ?>" class="btn btn-warning">Edit</a>
                                                <a href="<?php echo e(route('hapus_makanan',$m->id_menu)); ?>" class="btn btn-danger">Hapus</a>
                                            </center>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master_dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e-order\resources\views/dashboard/menu_makanan.blade.php ENDPATH**/ ?>
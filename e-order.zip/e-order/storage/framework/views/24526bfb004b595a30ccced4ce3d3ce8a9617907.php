
<?php $__env->startSection('judul','Form Edit Data'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-body">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <?php if($data->jenis == 1): ?>
            <center>
              <h1>Form Input Menu Makanan</h1>
            </center>
            <?php else: ?>
            <center>
              <h1>Form Input Menu Minuman</h1>
            </center>
            <?php endif; ?>
            <hr>
            <form action="<?php echo e(route('proses_edit_menu',$data->id_menu)); ?>" method="POST" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

              <input type="hidden" name="jenis" value="<?php echo e($data->jenis); ?>">
              <div class="form-group row">
                <div class="col-md-2"></div>
                <div class="col-md-8">
                  <label for="nama_menu" class="itam">Nama Menu</label>
                  <input type="text" value="<?php echo e($data->nama_menu); ?>" name="nama_menu" class="form-control" id="nama_menu" placeholder="Nama Menu">
                </div>
                <div class="col-md-2"></div>
              </div>
              <div class="form-group row">
                <div class="col-md-2"></div>
                <div class="col-md-8">
                  <label for="harga" class="itam">Harga</label>
                  <input type="text" name="harga" value="<?php echo e($data->harga); ?>" class="form-control" id="harga" placeholder="Harga">
                </div>
                <div class="col-md-2"></div>
              </div>
              <div class="form-group row">
                <div class="col-md-2"></div>
                <div class="col-md-8">
                  <label for="dapur" class="itam">Dapur</label>
                  <select class="form-control" name="id_dapur"id="single-select">
                    <?php $__currentLoopData = $dapur->where('id_dapur',$data->id_dapur); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($d->id_dapur); ?>"><?php echo e($d->nama_dapur); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <option>Pilih Kepala Dapur</option>
                    <?php $__currentLoopData = $dapur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($dp->id_dapur); ?>"><?php echo e($dp->nama_dapur); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="col-md-2"></div>
              </div>
              <div class="form-group row">
                <div class="col-md-2"></div>
                <div class="col-md-8">
                  <label for="foto" class="itam">Foto Makanan</label>
                  <input type="file" name="foto_makanan" id="imgInp">
                  <br>
                  <center>
                    <img src="<?php echo e(asset('foto_makanan/'.$data->foto_menu)); ?>" width="50%" id="blah">
                  </center>
                </div>
                <div class="col-md-2"></div>
              </div>
              <hr>
              <div class="form-group row">
                <div class="col-md-2"></div>
                <div class="col-md-8" align="right">
                  <button type="submit" class="btn btn-success"><i class="fa fa-paper-plane-o"></i> Simpan</button>
                  <a href="" class="btn btn-danger"><i class="fa fa-close"></i> Batal</a>
                </div>
                <div class="col-md-2"></div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master_dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e-order\resources\views/dashboard/makanan/form_edit.blade.php ENDPATH**/ ?>
<nav class="navbar navbar-light bg-light static-top">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <a href="<?php echo e(route('index')); ?>">
          <img src="<?php echo e(asset('mgg/mgg/mgg_menu3.png')); ?>" width="50%" alt="">
        </a>
      </div>
      <div class="col-lg-6" align="right">
        <a class="btn btn-success" href="<?php echo e(route('scan_meja')); ?>">Menu MGG</a>
      </div>
    </div>
  </div>
</nav>

<!-- Masthead -->
<header class="masthead text-white text-center" style="background: url('<?php echo e(asset('mgg/mgg/1.jpg')); ?>');background-repeat: no-repeat;background-size: cover;">
  <div class="overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-xl-12 mx-auto">
        <h1 class="mb-2">Melati Green Garden Cave and Resto</h1>
      </div>
    </div>
  </div>
</header><?php /**PATH C:\laragon\www\e-order\resources\views/include/_head.blade.php ENDPATH**/ ?>
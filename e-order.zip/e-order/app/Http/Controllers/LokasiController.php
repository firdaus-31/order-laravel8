<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Stevebauman\Location\Facades\Location;

class LokasiController extends Controller
{
    public function index(Request $request)
    {
        $ip = $request->ip();
        $userinfo = Location::get($ip);
        // dd($use);
        return view('lokasi', compact('userinfo'));
    }
}

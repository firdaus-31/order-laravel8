(function ($) {
    "use strict"

})(jQuery);
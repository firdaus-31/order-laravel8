@extends('include.master_dash')
@section('judul','Halaman Dashboard')
@section('content')
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-sm-6">
                <div class="card">
                    <div class="stat-widget-two card-body">
                        <div class="stat-content">
                            <div class="stat-text">Menu Makanan </div>
                            <div class="stat-digit"> {{$jumlah_makanan}}</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="card">
                    <div class="stat-widget-two card-body">
                        <div class="stat-content">
                            <div class="stat-text">Jumlah Minuman</div>
                            <div class="stat-digit"> {{$jumlah_minuman}}</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="card">
                    <div class="stat-widget-two card-body">
                        <div class="stat-content">
                            <div class="stat-text">Jumlah Meja Pelanggan</div>
                            <div class="stat-digit"> {{$jumlah_meja}}</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="card">
                    <div class="stat-widget-two card-body">
                        <div class="stat-content">
                            <div class="stat-text">Jumlah Orderan</div>
                            <div class="stat-digit"> {{$jumlah_pesanan}}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Dashboard</h4>
                    </div>
                    <div class="card-body">
                        <center>
                            <img src="{{asset('mgg/mgg/mgg_menu2.png')}}" width="70%">
                        </center>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
<nav class="navbar navbar-light bg-light static-top">
  <div class="container">
    <a href="{{route('index')}}">
      <img src="{{ asset('mgg/mgg/mgg_menu3.png') }}" width="25%" alt="">
    </a>
  </div>
</nav>

<!-- Masthead -->
<header class="masthead text-white text-center" style="background: url('{{ asset('mgg/mgg/1.jpg') }}');background-repeat: no-repeat;background-size: cover;">
  <div class="overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-xl-12 mx-auto">
        <h1 class="mb-2">Melati Green Garden Cave and Resto</h1>
      </div>
    </div>
  </div>
</header>